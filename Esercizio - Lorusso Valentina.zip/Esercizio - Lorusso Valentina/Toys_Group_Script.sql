CREATE SCHEMA `toys_group` ;

CREATE TABLE `toys_group`.`prodotto` (
  `id_prodotto` VARCHAR(8) NOT NULL,
  `nome_prodotto` VARCHAR(45) NOT NULL,
  `categoria_prodotto` VARCHAR(45) NOT NULL,
  `prezzo_prodotto` DECIMAL(19,2) NOT NULL,
  PRIMARY KEY (`id_prodotto`));
  
  CREATE TABLE `toys_group`.`regione` (
  `codice_regione` VARCHAR(6) NOT NULL,
  `nome_stato` VARCHAR(45) NOT NULL,
  `nome_citta` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`codice_regione`));

CREATE TABLE `toys_group`.`vendita` (
  `id_vendita` INT NOT NULL AUTO_INCREMENT,
  `data_vendita` DATE NOT NULL,
  `id_prodotto` VARCHAR(8) NOT NULL,
  `quantita_prodotto` INT NOT NULL,
  `codice_regione` VARCHAR(6) NOT NULL,
  `costo_totale` DECIMAL(19,2) NOT NULL,
  PRIMARY KEY (`id_vendita`));
  
  ALTER TABLE `toys_group`.`vendita` 
ADD INDEX `prodotto_vendita_idx` (`id_prodotto` ASC) VISIBLE;
;
ALTER TABLE `toys_group`.`vendita` 
ADD CONSTRAINT `prodotto_vendita`
  FOREIGN KEY (`id_prodotto`)
  REFERENCES `toys_group`.`prodotto` (`id_prodotto`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
  ALTER TABLE `toys_group`.`vendita` 
ADD INDEX `regione_vendita_idx` (`codice_regione` ASC) VISIBLE;
;
ALTER TABLE `toys_group`.`vendita` 
ADD CONSTRAINT `regione_vendita`
  FOREIGN KEY (`codice_regione`)
  REFERENCES `toys_group`.`regione` (`codice_regione`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
  INSERT INTO toys_group.prodotto (id_prodotto, nome_prodotto, categoria_prodotto, prezzo_prodotto)
VALUES
  ('PROD001', 'Bambola Barbie', 'Bambole', 19.99),
  ('PROD002', 'Macchina Telecomandata', 'Veicoli', 24.95),
  ('PROD003', 'Gioco di Costruzioni', 'Giochi Educativi', 39.90),
  ('PROD004', 'Puzzle 100 Pezzi', 'Giochi di Società', 14.99),
  ('PROD005', 'Orsetto di Peluche', 'Peluche', 12.99),
  ('PROD006', 'Palline Colorate', 'Giochi per Bambini', 8.99),
  ('PROD007', 'Stoviglie Giocattolo', 'Giochi di Imitazione', 15.50),
  ('PROD008', 'Set di Disegno', 'Attrezzi da Disegno', 9.90),
  ('PROD009', 'Gioco di Carte', 'Giochi di Società', 11.99),
  ('PROD010', 'Lego City', 'Giochi di Costruzioni', 49.99);
  
  INSERT INTO toys_group.regione (codice_regione, nome_stato, nome_citta)
VALUES
  ('IT001', 'Italia', 'Roma'),
  ('FR001', 'Francia', 'Parigi'),
  ('DE001', 'Germania', 'Berlino'),
  ('ES001', 'Spagna', 'Madrid'),
  ('GB001', 'Regno Unito', 'Londra'),
  ('US001', 'Stati Uniti', 'New York'),
  ('CA001', 'Canada', 'Toronto'),
  ('AU001', 'Australia', 'Sydney'),
  ('JP001', 'Giappone', 'Tokyo'),
  ('KR001', 'Corea del Sud', 'Seul');
  
  INSERT INTO toys_group.vendita (data_vendita, id_prodotto, quantita_prodotto, codice_regione, costo_totale)
VALUES
  ('2024-05-24', 'PROD001', 1, 'IT001', 19.99),
  ('2024-05-23', 'PROD003', 2, 'FR001', 79.80),
  ('2024-05-22', 'PROD003', 3, 'DE001', 119.7),
  ('2024-05-21', 'PROD003', 4, 'IT001', 159.60),
  ('2024-05-20', 'PROD009', 5, 'FR001', 59.95),
  ('2024-05-19', 'PROD007', 6, 'DE001', 93),
  ('2024-05-18', 'PROD005', 1, 'IT001', 12.99),
  ('2024-05-17', 'PROD001', 8, 'FR001', 159.92),
  ('2024-05-16', 'PROD001', 1, 'DE001', 19.99),
  ('2024-05-15', 'PROD002', 2, 'IT001', 49.90);
  
/*PARTE 2: SCRITTURA QUERY*/
/*1. Verificare che i campi definiti come PK siano univoci*/
SELECT 
    COUNT(prodotto.id_prodotto) AS NColonneProd,
    COUNT(DISTINCT prodotto.id_prodotto) AS NoRipProd
FROM
    prodotto;

SELECT 
    COUNT(regione.codice_regione) AS NColonneReg,
    COUNT(DISTINCT regione.codice_regione) AS NoRipReg
FROM
    regione;

SELECT 
    COUNT(vendita.id_vendita) AS NColonneVen,
    COUNT(DISTINCT vendita.id_vendita) AS NoRipVen
FROM
    vendita;
    
/*2. Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/
SELECT 
    prodotto.nome_prodotto AS Prodotto,
    SUM(vendita.costo_totale) AS FatturatoTotAnno
FROM
    prodotto
        LEFT JOIN
    vendita ON prodotto.id_prodotto = vendita.id_prodotto
WHERE
    vendita.quantita_prodotto >= 1
GROUP BY prodotto.nome_prodotto;

/*3. Esporre il fatturato totale per stato per anno. Ordinare il risultato per data e per fatturato descrescente*/
SELECT 
    regione.nome_stato AS Stato,
    SUM(vendita.costo_totale) AS FatturatoTotAnno
FROM
    regione
        LEFT JOIN
    vendita ON regione.codice_regione = vendita.codice_regione
GROUP BY regione.nome_stato
ORDER BY FatturatoTotAnno DESC;

/*4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */
SELECT 
    prodotto.categoria_prodotto AS Categoria, 
    SUM(vendita.quantita_prodotto) AS QuantitaVendute
FROM
    prodotto
        LEFT JOIN
    vendita ON prodotto.id_prodotto = vendita.id_prodotto
GROUP BY categoria_prodotto
ORDER BY QuantitaVendute DESC;

/*5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti*/
/* APPROCCIO 1: VEDERE QUALI SONO I PRODOTTI CHE HANNO QUANTITA' VENDUTE PARI A ZERO QUINDI NULLE */
SELECT 
    prodotto.nome_prodotto AS Prodotto,
    count(vendita.quantita_prodotto) AS QuantitaVendute
FROM
    prodotto
        LEFT JOIN
    vendita ON prodotto.id_prodotto = vendita.id_prodotto
GROUP BY prodotto.nome_prodotto
having count(vendita.quantita_prodotto) = 'null';

/*APPROCCIO 2: VEDERE QUALI SONO GLI ID_PRODOTTO DELLA TABELLA 'PRODOTTO' CHE NON SONO PRESENTI NELLA LISTA ID_PRODOTTO DELLA TABELLA 'VENDITA'*/
SELECT 
    prodotto.nome_prodotto as Prodotto
FROM
    prodotto
WHERE
    id_prodotto NOT IN (SELECT 
            id_prodotto
        FROM
            vendita);

/*6. Esporre l'elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente) */
SELECT 
    prodotto.nome_prodotto,
    MAX(vendita.data_vendita) AS UltimaVendita
FROM
    prodotto
        JOIN
    vendita ON prodotto.id_prodotto = vendita.id_prodotto
GROUP BY prodotto.nome_prodotto
ORDER BY UltimaVendita DESC;